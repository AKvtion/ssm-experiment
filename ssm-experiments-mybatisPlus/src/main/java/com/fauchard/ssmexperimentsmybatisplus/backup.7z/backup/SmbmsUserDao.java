package com.fauchard.ssmexperimentsmybatisplus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fauchard.ssmexperimentsmybatisplus.entity.SmbmsUser;
import org.apache.ibatis.annotations.Mapper;

/**
 * (SmbmsUser)表数据库访问层
 *
 * @author fauchard
 * @since 2023-06-11 17:26:25
 */
@Mapper
public interface SmbmsUserDao extends BaseMapper<SmbmsUser> {

}

