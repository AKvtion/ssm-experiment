package com.fauchard.ssmexperimentsmybatisplus.controller;



import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fauchard.ssmexperimentsmybatisplus.entity.Result;
import com.fauchard.ssmexperimentsmybatisplus.entity.SmbmsUser;
import com.fauchard.ssmexperimentsmybatisplus.service.SmbmsUserService;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
* (SmbmsUser)表控制层
*
* @author fauchard
* @since 2023-06-11 20:20:23
  */
  @RestController
  @RequestMapping("smbmsUser")
  public class SmbmsUserController{
  /**
    * 服务对象
      */
      @Resource
      private SmbmsUserService smbmsUserService;


    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("{id}")
    public Result selectOne(@PathVariable Serializable id) {
        return new Result().success(this.smbmsUserService.getById(id));
    }

    /**
     * 新增数据
     *
     * @param smbmsUser 实体对象
     * @return 新增结果
     */
    @PostMapping
    public Result insert(@RequestBody SmbmsUser smbmsUser) {
        return new Result().success(this.smbmsUserService.save(smbmsUser));
    }

    /**
     * 修改数据
     *
     * @param smbmsUser 实体对象
     * @return 修改结果
     */
    @PutMapping
    public Result update(@RequestBody SmbmsUser smbmsUser) {
        return new Result().success(this.smbmsUserService.updateById(smbmsUser));
    }

    /**
     * 删除数据
     *
     * @param idList 主键结合
     * @return 删除结果
     */
    @DeleteMapping
    public Result delete(@RequestParam("idList") List<Long> idList) {
        return new Result().success(this.smbmsUserService.removeByIds(idList));
    }

}

        