package com.fauchard.ssmexperimentsmybatisplus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fauchard.ssmexperimentsmybatisplus.entity.SmbmsUser;

/**
 * (SmbmsUser)表服务接口
 *
 * @author fauchard
 * @since 2023-06-11 17:26:26
 */
public interface SmbmsUserService extends IService<SmbmsUser> {

}

