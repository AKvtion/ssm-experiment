package com.fauchard.ssmexperimentsmybatisplus.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fauchard.ssmexperimentsmybatisplus.mapper.SmbmsUserDao;
import com.fauchard.ssmexperimentsmybatisplus.entity.SmbmsUser;
import com.fauchard.ssmexperimentsmybatisplus.service.SmbmsUserService;
import org.springframework.stereotype.Service;

/**
 * (SmbmsUser)表服务实现类
 *
 * @author fauchard
 * @since 2023-06-11 17:26:27
 */
@Service
public class SmbmsUserServiceImpl extends ServiceImpl<SmbmsUserDao, SmbmsUser> implements SmbmsUserService {

}

