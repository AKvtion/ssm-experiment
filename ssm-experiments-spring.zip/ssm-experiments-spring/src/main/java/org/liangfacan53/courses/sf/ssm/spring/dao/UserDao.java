package org.liangfacan53.courses.sf.ssm.spring.dao;

import org.liangfacan53.courses.sf.ssm.spring.pojo.User;

public interface UserDao {
    int updateUserById(User user);
}
