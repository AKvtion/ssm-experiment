package org.liangfacan53.courses.sf.ssm.spring.service;

import org.liangfacan53.courses.sf.ssm.spring.dao.UserDao;
import org.liangfacan53.courses.sf.ssm.spring.pojo.User;


public class UserServiceImpl implements UserService{
    private UserDao userDao;

    @Override
    public boolean updateUserById(User user, int id) {
        user.setId(id);
        return userDao.updateUserById(user) == 1;
    }
}
